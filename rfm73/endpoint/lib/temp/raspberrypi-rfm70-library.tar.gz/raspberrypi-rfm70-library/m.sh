#!/bin/bash
make clean
make rfm70_test
